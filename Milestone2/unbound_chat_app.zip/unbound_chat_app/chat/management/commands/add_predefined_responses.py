# chat/management/commands/add_predefined_responses.py
from django.core.management.base import BaseCommand
from chat.models import ProviderResponse

class Command(BaseCommand):
    help = 'Add predefined responses for providers'

    def handle(self, *args, **kwargs):
        responses = [
            {
                'provider': 'openai',
                'model': 'gpt-3.5',
                'response': 'OpenAI: Processed your prompt with advanced language understanding. Response ID: openai_response_001'
            },
            {
                'provider': 'anthropic',
                'model': 'claude-v1',
                'response': 'Anthropic: Your prompt has been interpreted with ethical AI principles. Response ID: anthropic_response_002'
            }
        ]
        
        for response in responses:
            ProviderResponse.objects.create(**response)

        self.stdout.write(self.style.SUCCESS('Successfully added predefined responses'))
