# chat/urls.py
from django.urls import path
from .views import models_list, index, chat_completions

urlpatterns = [
    path('', index, name='index'),
    path('models/', models_list, name='models_list'),
    path('v1/chat/completions', chat_completions, name='chat_completions'),
]
