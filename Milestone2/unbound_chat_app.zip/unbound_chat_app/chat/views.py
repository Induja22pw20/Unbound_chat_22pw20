# chat/views.py
from django.http import JsonResponse, HttpResponseBadRequest
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from .models import ModelProvider, ProviderResponse
import json

def models_list(request):
    models = ModelProvider.objects.all()
    model_names = [model.name for model in models]
    return JsonResponse(model_names, safe=False)

def index(request):
    return render(request, 'chat/index.html')

@csrf_exempt
def chat_completions(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
        except json.JSONDecodeError as e:
            return HttpResponseBadRequest(f'Invalid JSON: {str(e)}')

        provider = data.get('provider')
        model = data.get('model')
        prompt = data.get('prompt')

        if not provider or not model or not prompt:
            return HttpResponseBadRequest('Invalid request body')

        try:
            ModelProvider.objects.get(name=f'{provider}/{model}')
        except ModelProvider.DoesNotExist:
            return HttpResponseBadRequest('Invalid provider or model')

        response = ProviderResponse.objects.filter(provider=provider, model=model).first()
        if response:
            return JsonResponse({
                'provider': provider,
                'model': model,
                'response': response.response
            })
        else:
            return HttpResponseBadRequest('No predefined response found')

    return HttpResponseBadRequest('Invalid request method')
