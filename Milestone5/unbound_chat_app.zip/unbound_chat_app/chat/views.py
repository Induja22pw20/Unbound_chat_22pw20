from django.http import JsonResponse, HttpResponseBadRequest, HttpResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from .models import ModelProvider, ProviderResponse, RegexPolicy, Provider
import json
import re

def get_providers(request):
    providers = Provider.objects.all().values('name')
    return JsonResponse(list(providers), safe=False)

def get_models(request):
    models = ModelProvider.objects.all().values('name')
    model_names = [model['name'] for model in models]
    return JsonResponse(model_names, safe=False)

def index(request):
    return render(request, 'chat/index.html')

def models_list(request):
    models = ModelProvider.objects.all()
    return render(request, 'chat/models_list.html', {'models': models})

@csrf_exempt
def chat_completions(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
        except json.JSONDecodeError as e:
            return HttpResponseBadRequest(f'Invalid JSON: {str(e)}')

        provider = data.get('provider')
        model = data.get('model')
        prompt = data.get('prompt')

        if not provider or not model or not prompt:
            return HttpResponseBadRequest('Invalid request body')

        # Debugging info
        print(f'Provider: {provider}, Model: {model}, Prompt: {prompt}')

        # Reroute if the provider is "openai" and model is "gpt-4o"
        if provider == "openai" and model == "gpt-4o":
            print('Rerouting: gpt-4o to gemini-alpha')  # Debugging info
            model = "gemini-alpha"

        # Check for regex match and reroute if needed
        regex_policies = RegexPolicy.objects.filter(original_model=model)
        for policy in regex_policies:
            if re.search(policy.pattern, prompt):
                print(f'Rerouting based on regex: {model} to {policy.redirect_model}')  # Debugging info
                model = policy.redirect_model
                break

        try:
            ModelProvider.objects.get(name=f'{provider}/{model}')
        except ModelProvider.DoesNotExist:
            return HttpResponseBadRequest('Invalid provider or model')

        response = ProviderResponse.objects.filter(provider=provider, model=model).first()
        if response:
            return JsonResponse({
                'provider': provider,
                'model': model,
                'response': response.response
            })
        else:
            return HttpResponseBadRequest('No predefined response found')

    return HttpResponseBadRequest('Invalid request method')

def admin_portal(request):
    return render(request, 'chat/admin_page.html')

@csrf_exempt
def fetch_regex_rules(request):
    if request.method == 'GET':
        rules = RegexPolicy.objects.all()
        rules_list = [
            {'id': rule.id, 'pattern': rule.pattern, 'original_model': rule.original_model, 'redirect_model': rule.redirect_model}
            for rule in rules
        ]
        return JsonResponse(rules_list, safe=False)
    return HttpResponseBadRequest('Invalid request method')

@csrf_exempt
def add_regex_rule(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            pattern = data.get('pattern')
            original_model = data.get('original_model')
            redirect_model = data.get('redirect_model')
            if not pattern or not original_model or not redirect_model:
                return HttpResponseBadRequest('Missing fields')
            RegexPolicy.objects.create(pattern=pattern, original_model=original_model, redirect_model=redirect_model)
            return JsonResponse({'message': 'Regex rule added successfully'})
        except json.JSONDecodeError as e:
            return HttpResponseBadRequest(f'Invalid JSON: {str(e)}')
    return HttpResponseBadRequest('Invalid request method')

@csrf_exempt
def delete_regex_rule(request, id):
    if request.method == 'DELETE':
        try:
            rule = RegexPolicy.objects.get(id=id)
            rule.delete()
            return JsonResponse({'message': 'Regex rule deleted successfully'})
        except RegexPolicy.DoesNotExist:
            return HttpResponseBadRequest('Regex rule not found')
    return HttpResponseBadRequest('Invalid request method')

@csrf_exempt
def edit_regex_rule(request, id):
    if request.method == 'PUT':
        try:
            data = json.loads(request.body)
            pattern = data.get('pattern')
            original_model = data.get('original_model')
            redirect_model = data.get('redirect_model')
            if not pattern or not original_model or not redirect_model:
                return HttpResponseBadRequest('Missing fields')
            rule = RegexPolicy.objects.get(id=id)
            rule.pattern = pattern
            rule.original_model = original_model
            rule.redirect_model = redirect_model
            rule.save()
            return JsonResponse({'message': 'Regex rule updated successfully'})
        except json.JSONDecodeError as e:
            return HttpResponseBadRequest(f'Invalid JSON: {str(e)}')
        except RegexPolicy.DoesNotExist:
            return HttpResponseBadRequest('Regex rule not found')
    return HttpResponseBadRequest('Invalid request method')