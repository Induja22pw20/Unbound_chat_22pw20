from django.db import models

class ModelProvider(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class RegexPolicy(models.Model):
    pattern = models.CharField(max_length=100)
    original_model = models.CharField(max_length=100, default='default_model')
    redirect_model = models.CharField(max_length=100, default='default_redirect_model')

    def __str__(self):
        return f'{self.pattern} -> {self.redirect_model}'

class ProviderResponse(models.Model):
    provider = models.CharField(max_length=100)
    model = models.CharField(max_length=100)
    response = models.TextField()

    def __str__(self):
        return f'{self.provider} - {self.model}'

class Provider(models.Model):
    name = models.CharField(max_length=100)
    api_key = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class FileUpload(models.Model):
    file = models.FileField(upload_to='uploads/')
    uploaded_at = models.DateTimeField(auto_now_add=True)