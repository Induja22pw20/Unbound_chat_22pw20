from django.urls import path
from .views import index, chat_completions, admin_portal, fetch_regex_rules, add_regex_rule, delete_regex_rule, edit_regex_rule, get_providers, get_models, models_list

urlpatterns = [
    path('', index, name='index'),
    path('chat/completions/', chat_completions, name='chat_completions'),
    path('custom-admin/', admin_portal, name='admin_portal'),
    path('fetch-regex-rules/', fetch_regex_rules, name='fetch_regex_rules'),
    path('add-regex-rule/', add_regex_rule, name='add_regex_rule'),
    path('delete-regex-rule/<int:id>/', delete_regex_rule, name='delete_regex_rule'),
    path('edit-regex-rule/<int:id>/', edit_regex_rule, name='edit_regex_rule'),
    path('get-providers/', get_providers, name='get_providers'),
    path('get-models/', get_models, name='get_models'),
    path('models-list/', models_list, name='models_list'),
]