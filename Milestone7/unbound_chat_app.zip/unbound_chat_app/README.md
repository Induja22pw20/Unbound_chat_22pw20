# Unbound Chat App

Unbound Chat App is a Django-based web application that provides a chat interface with AI models from various providers. It includes an admin portal for managing regex rules for routing prompts to different models.

## Features

- Chat interface with AI models
- Admin portal for managing regex rules
- File upload support
- Predefined responses for providers

## Installation

1. Clone the repository:

   ```sh
   git clone https://github.com/yourusername/unbound_chat_app.git
   cd unbound_chat_app
   ```

2. Create a virtual environment and activate it:

   ```sh
   python -m venv venv
   source venv/bin/activate  # On Windows use `venv\Scripts\activate`
   ```

3. Install the dependencies:

   ```sh
   pip install -r requirements.txt
   ```

4. Apply the migrations:

   ```sh
   python manage.py migrate
   ```

5. Create a superuser:

   ```sh
   python manage.py createsuperuser
   ```

6. Run the development server:

   ```sh
   python manage.py runserver
   ```

7. Open your browser and go to `http://127.0.0.1:8000/` to access the chat interface.

## Usage

### Chat Interface

- Select a provider and model.
- Enter your prompt and optionally upload a file.
- Click "Send" to get a response from the selected model.

### Admin Portal

- Go to `http://127.0.0.1:8000/custom-admin/` to access the admin portal.
- Add new regex rules for routing prompts to different models.
- View, edit, and delete existing regex rules.

## Management Commands

- `add_model_data`: Adds sample model data to the database.
- `add_regex_policies`: Adds regex policies for routing.
- `add_predefined_responses`: Adds predefined responses for providers.

## Project Structure

unbound_chat_app/ chat/ init.py admin.py apps.py management/ commands/ add_model_data.py add_regex_policies.py add_predefined_responses.py migrations/ init.py 0001_initial.py 0002_aimodel.py 0003_alter_modelprovider_name_regexpolicy_delete_aimodel.py 0004_providerresponse.py 0005_remove_regexpolicy_model_provider_and_more.py 0006_alter_regexpolicy_original_model_and_more.py 0007_fileupload_provider_alter_regexpolicy_original_model_and_more.py models.py static/ css/ admin-styles.css styles.css templates/ chat/ admin_page.html index.html tests.py urls.py views.py db.sqlite3 manage.py static/ css/ styles.css unbound_chat_app/ init.py asgi.py settings.py urls.py wsgi.py
