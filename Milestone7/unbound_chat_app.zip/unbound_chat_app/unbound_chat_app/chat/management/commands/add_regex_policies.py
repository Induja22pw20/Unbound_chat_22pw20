# chat/management/commands/add_regex_policies.py
from django.core.management.base import BaseCommand
from chat.models import RegexPolicy

class Command(BaseCommand):
    help = 'Add regex policies for routing'

    def handle(self, *args, **kwargs):
        policies = [
            {
                'pattern': '(?i)(credit card)',
                'original_model': 'gpt-4o',
                'redirect_model': 'gemini-alpha'
            },
            # Add more policies here
        ]
        
        for policy in policies:
            RegexPolicy.objects.create(**policy)

        self.stdout.write(self.style.SUCCESS('Successfully added regex policies'))
